'use strict';

const http = require('node:http');
const path = require('node:path');
const fs = require('node:fs');
const { Router } = require('./lib/router');
const { notFound, serverError } = require('./lib/http-utils');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');

const router = new Router();
require('./routes/players').register(router);
require('./routes/matches').register(router);
require('./routes/stats').register(router);
require('./routes/tournaments').register(router);

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

function serveStatic(req, res, pathname) {
  let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);

  // Empêche toute évasion du dossier public/.
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    return res.end('Interdit');
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // Pour une route "SPA-like" sans extension, retombe sur index.html.
      if (!path.extname(pathname)) {
        filePath = path.join(PUBLIC_DIR, 'index.html');
        return fs.readFile(filePath, (err2, data) => {
          if (err2) return notFound(res, 'Page introuvable.');
          res.writeHead(200, { 'Content-Type': MIME_TYPES['.html'] });
          res.end(data);
        });
      }
      return notFound(res, 'Fichier introuvable.');
    }
    const ext = path.extname(filePath);
    fs.readFile(filePath, (readErr, data) => {
      if (readErr) return serverError(res, readErr);
      res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
      res.end(data);
    });
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;

  if (pathname.startsWith('/api/')) {
    const handled = await router.handle(req, res, pathname);
    if (!handled) notFound(res, 'Route API introuvable.');
    return;
  }

  serveStatic(req, res, pathname);
});

server.listen(PORT, () => {
  console.log(`🎯 Darts App lancée sur http://localhost:${PORT}`);
});
