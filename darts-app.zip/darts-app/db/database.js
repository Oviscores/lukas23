'use strict';

const path = require('node:path');
const fs = require('node:fs');
const { DatabaseSync } = require('node:sqlite');

const DB_PATH = path.join(__dirname, 'darts.sqlite3');
const SCHEMA_PATH = path.join(__dirname, 'schema.sql');

const isNewDb = !fs.existsSync(DB_PATH);

const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA foreign_keys = ON;');
db.exec('PRAGMA journal_mode = WAL;');

// Applique le schéma à chaque démarrage (toutes les instructions sont IF NOT EXISTS).
const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
db.exec(schema);

if (isNewDb) {
  console.log(`Nouvelle base de données créée : ${DB_PATH}`);
} else {
  console.log(`Base de données ouverte : ${DB_PATH}`);
}

/**
 * Exécute une requête SELECT et retourne toutes les lignes.
 */
function all(sql, params = []) {
  const stmt = db.prepare(sql);
  return stmt.all(...params);
}

/**
 * Exécute une requête SELECT et retourne la première ligne (ou undefined).
 */
function get(sql, params = []) {
  const stmt = db.prepare(sql);
  return stmt.get(...params);
}

/**
 * Exécute une requête INSERT/UPDATE/DELETE.
 * Retourne { lastInsertRowid, changes }.
 */
function run(sql, params = []) {
  const stmt = db.prepare(sql);
  const info = stmt.run(...params);
  return { lastInsertRowid: Number(info.lastInsertRowid), changes: Number(info.changes) };
}

/**
 * Exécute une fonction dans une transaction SQLite.
 */
function transaction(fn) {
  db.exec('BEGIN');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

module.exports = { db, all, get, run, transaction };
