-- Schéma de la base de données "Darts App"
-- SQLite (via le module natif node:sqlite)

PRAGMA foreign_keys = ON;

-- Joueurs
CREATE TABLE IF NOT EXISTS players (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL UNIQUE,
  color      TEXT NOT NULL DEFAULT '#e11d48',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Tournois / ligues
CREATE TABLE IF NOT EXISTS tournaments (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  format      TEXT NOT NULL DEFAULT 'round_robin' CHECK (format IN ('round_robin', 'knockout')),
  game_type   TEXT NOT NULL DEFAULT '501' CHECK (game_type IN ('501', '301')),
  legs_to_win INTEGER NOT NULL DEFAULT 3,
  status      TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'finished')),
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at TEXT
);

-- Participants d'un tournoi
CREATE TABLE IF NOT EXISTS tournament_players (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  tournament_id INTEGER NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  player_id     INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  UNIQUE (tournament_id, player_id)
);

-- Parties (matchs) : un match se joue en "best of N legs"
CREATE TABLE IF NOT EXISTS matches (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  game_type        TEXT NOT NULL DEFAULT '501' CHECK (game_type IN ('501', '301')),
  legs_to_win      INTEGER NOT NULL DEFAULT 3,
  status           TEXT NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'finished')),
  winner_player_id INTEGER REFERENCES players(id),
  tournament_id    INTEGER REFERENCES tournaments(id) ON DELETE CASCADE,
  round            INTEGER,
  created_at       TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at      TEXT
);

-- Joueurs participant à un match, avec leur ordre de passage
CREATE TABLE IF NOT EXISTS match_players (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  match_id     INTEGER NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  player_id    INTEGER NOT NULL REFERENCES players(id),
  player_order INTEGER NOT NULL DEFAULT 0,
  UNIQUE (match_id, player_id)
);

-- Manches (legs) d'un match
CREATE TABLE IF NOT EXISTS legs (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  match_id           INTEGER NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  leg_number         INTEGER NOT NULL,
  starting_player_id INTEGER NOT NULL REFERENCES players(id),
  winner_player_id   INTEGER REFERENCES players(id),
  status             TEXT NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'finished')),
  created_at         TEXT NOT NULL DEFAULT (datetime('now')),
  finished_at        TEXT
);

-- Tours (visites de 3 fléchettes) joués pendant une manche
CREATE TABLE IF NOT EXISTS turns (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  leg_id           INTEGER NOT NULL REFERENCES legs(id) ON DELETE CASCADE,
  match_id         INTEGER NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  player_id        INTEGER NOT NULL REFERENCES players(id),
  turn_number      INTEGER NOT NULL,
  score             INTEGER NOT NULL,
  darts_used        INTEGER NOT NULL DEFAULT 3,
  is_bust           INTEGER NOT NULL DEFAULT 0,
  is_checkout       INTEGER NOT NULL DEFAULT 0,
  remaining_before  INTEGER NOT NULL,
  remaining_after   INTEGER NOT NULL,
  created_at        TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_match_players_match ON match_players(match_id);
CREATE INDEX IF NOT EXISTS idx_match_players_player ON match_players(player_id);
CREATE INDEX IF NOT EXISTS idx_legs_match ON legs(match_id);
CREATE INDEX IF NOT EXISTS idx_turns_leg ON turns(leg_id);
CREATE INDEX IF NOT EXISTS idx_turns_match ON turns(match_id);
CREATE INDEX IF NOT EXISTS idx_turns_player ON turns(player_id);
CREATE INDEX IF NOT EXISTS idx_matches_tournament ON matches(tournament_id);
CREATE INDEX IF NOT EXISTS idx_tournament_players_tournament ON tournament_players(tournament_id);
