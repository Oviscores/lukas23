'use strict';

const Api = {
  async _fetch(method, url, body) {
    const opts = { method, headers: {} };
    if (body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    const res = await fetch(url, opts);
    let data = null;
    try { data = await res.json(); } catch (e) { /* pas de corps JSON */ }
    if (!res.ok) {
      const err = new Error((data && data.error) || `Erreur HTTP ${res.status}`);
      err.status = res.status;
      throw err;
    }
    return data;
  },

  get(url) { return this._fetch('GET', url); },
  post(url, body) { return this._fetch('POST', url, body || {}); },
  put(url, body) { return this._fetch('PUT', url, body || {}); },
  del(url) { return this._fetch('DELETE', url); },

  players: {
    list: () => Api.get('/api/players'),
    get: (id) => Api.get(`/api/players/${id}`),
    create: (data) => Api.post('/api/players', data),
    update: (id, data) => Api.put(`/api/players/${id}`, data),
    remove: (id) => Api.del(`/api/players/${id}`),
  },

  matches: {
    list: () => Api.get('/api/matches'),
    get: (id) => Api.get(`/api/matches/${id}`),
    create: (data) => Api.post('/api/matches', data),
    remove: (id) => Api.del(`/api/matches/${id}`),
    addTurn: (id, data) => Api.post(`/api/matches/${id}/turns`, data),
    undo: (id) => Api.post(`/api/matches/${id}/undo`),
  },

  stats: {
    leaderboard: () => Api.get('/api/stats/leaderboard'),
    overview: () => Api.get('/api/stats/overview'),
  },

  tournaments: {
    list: () => Api.get('/api/tournaments'),
    get: (id) => Api.get(`/api/tournaments/${id}`),
    create: (data) => Api.post('/api/tournaments', data),
    remove: (id) => Api.del(`/api/tournaments/${id}`),
    advance: (id) => Api.post(`/api/tournaments/${id}/advance`),
  },

  checkoutSuggestion: (remaining, dartsLeft) =>
    Api.get(`/api/checkout-suggestion?remaining=${remaining}&dartsLeft=${dartsLeft || 3}`),
};

function fmtDate(iso) {
  if (!iso) return '';
  const d = new Date(iso.replace(' ', 'T') + 'Z');
  return d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }) +
    ' ' + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}

function escapeHtml(str) {
  return String(str ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function qs(name) {
  return new URLSearchParams(window.location.search).get(name);
}

function showToast(message, isError) {
  let el = document.getElementById('toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'toast';
    el.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);' +
      'padding:12px 20px;border-radius:10px;font-weight:700;font-size:14px;z-index:200;' +
      'box-shadow:0 4px 16px rgba(0,0,0,0.4);transition:opacity 0.2s;';
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.style.background = isError ? '#7a1622' : '#1fae5f';
  el.style.color = '#fff';
  el.style.opacity = '1';
  clearTimeout(el._timeout);
  el._timeout = setTimeout(() => { el.style.opacity = '0'; }, 2600);
}
