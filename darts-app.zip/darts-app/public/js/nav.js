'use strict';

function renderNav(active) {
  const links = [
    { href: '/', label: 'Accueil', key: 'home' },
    { href: '/players.html', label: 'Joueurs', key: 'players' },
    { href: '/new-match.html', label: 'Nouvelle partie', key: 'new-match' },
    { href: '/history.html', label: 'Historique', key: 'history' },
    { href: '/stats.html', label: 'Statistiques', key: 'stats' },
    { href: '/tournaments.html', label: 'Tournois', key: 'tournaments' },
  ];

  const header = document.createElement('header');
  header.className = 'topnav';
  header.innerHTML = `
    <div class="topnav-inner">
      <a href="/" class="brand"><span class="dot">🎯</span> Fléchettes</a>
      <nav class="links">
        ${links.map((l) => `<a href="${l.href}" class="${l.key === active ? 'active' : ''}">${l.label}</a>`).join('')}
      </nav>
    </div>
  `;
  document.body.insertBefore(header, document.body.firstChild);
}
