'use strict';

const db = require('../db/database');
const { ok, created, badRequest, notFound } = require('../lib/http-utils');

function register(router) {
  // Liste des joueurs avec un résumé de stats.
  router.get('/api/players', (req, res) => {
    const players = db.all(`
      SELECT p.id, p.name, p.color, p.created_at,
        (SELECT COUNT(*) FROM match_players mp WHERE mp.player_id = p.id) AS matches_played,
        (SELECT COUNT(*) FROM matches m WHERE m.winner_player_id = p.id) AS matches_won
      FROM players p
      ORDER BY p.name COLLATE NOCASE ASC
    `);
    ok(res, players);
  });

  router.post('/api/players', (req, res) => {
    const { name, color } = req.body;
    if (!name || typeof name !== 'string' || !name.trim()) {
      return badRequest(res, 'Le nom du joueur est requis.');
    }
    const existing = db.get('SELECT id FROM players WHERE name = ?', [name.trim()]);
    if (existing) return badRequest(res, 'Un joueur avec ce nom existe déjà.');

    const { lastInsertRowid } = db.run(
      'INSERT INTO players (name, color) VALUES (?, ?)',
      [name.trim(), color || randomColor()]
    );
    const player = db.get('SELECT * FROM players WHERE id = ?', [lastInsertRowid]);
    created(res, player);
  });

  router.get('/api/players/:id', (req, res) => {
    const player = db.get('SELECT * FROM players WHERE id = ?', [req.params.id]);
    if (!player) return notFound(res, 'Joueur introuvable.');

    const stats = computePlayerStats(req.params.id);
    ok(res, { ...player, stats });
  });

  router.put('/api/players/:id', (req, res) => {
    const player = db.get('SELECT * FROM players WHERE id = ?', [req.params.id]);
    if (!player) return notFound(res, 'Joueur introuvable.');
    const { name, color } = req.body;
    db.run('UPDATE players SET name = ?, color = ? WHERE id = ?', [
      name && name.trim() ? name.trim() : player.name,
      color || player.color,
      req.params.id,
    ]);
    ok(res, db.get('SELECT * FROM players WHERE id = ?', [req.params.id]));
  });

  router.delete('/api/players/:id', (req, res) => {
    const player = db.get('SELECT * FROM players WHERE id = ?', [req.params.id]);
    if (!player) return notFound(res, 'Joueur introuvable.');
    db.run('DELETE FROM players WHERE id = ?', [req.params.id]);
    ok(res, { deleted: true });
  });
}

function randomColor() {
  const palette = ['#e11d48', '#2563eb', '#059669', '#d97706', '#7c3aed', '#0891b2', '#db2777', '#65a30d'];
  return palette[Math.floor(Math.random() * palette.length)];
}

function computePlayerStats(playerId) {
  const totals = db.get(`
    SELECT
      COALESCE(SUM(score), 0) AS total_points,
      COALESCE(SUM(darts_used), 0) AS total_darts,
      COALESCE(MAX(CASE WHEN is_bust = 0 THEN score END), 0) AS highest_turn,
      COALESCE(SUM(CASE WHEN score = 180 AND is_bust = 0 THEN 1 ELSE 0 END), 0) AS count_180,
      COALESCE(SUM(CASE WHEN is_checkout = 1 THEN 1 ELSE 0 END), 0) AS checkouts_hit,
      COALESCE(MAX(CASE WHEN is_checkout = 1 THEN score END), 0) AS best_checkout
    FROM turns WHERE player_id = ? AND is_bust = 0
  `, [playerId]);

  const matches = db.get(`
    SELECT
      (SELECT COUNT(*) FROM match_players WHERE player_id = ?) AS matches_played,
      (SELECT COUNT(*) FROM matches WHERE winner_player_id = ?) AS matches_won,
      (SELECT COUNT(*) FROM legs WHERE winner_player_id = ?) AS legs_won
  `, [playerId, playerId, playerId]);

  const average = totals.total_darts > 0 ? (totals.total_points / totals.total_darts) * 3 : 0;

  const recentAverages = db.all(`
    SELECT m.id AS match_id, m.created_at,
      SUM(t.score) AS points, SUM(t.darts_used) AS darts
    FROM matches m
    JOIN turns t ON t.match_id = m.id AND t.player_id = ? AND t.is_bust = 0
    WHERE m.id IN (SELECT match_id FROM match_players WHERE player_id = ?)
    GROUP BY m.id
    ORDER BY m.created_at DESC
    LIMIT 15
  `, [playerId, playerId]).reverse().map((r) => ({
    match_id: r.match_id,
    created_at: r.created_at,
    average: r.darts > 0 ? Number(((r.points / r.darts) * 3).toFixed(2)) : 0,
  }));

  return {
    average: Number(average.toFixed(2)),
    highest_turn: totals.highest_turn,
    count_180: totals.count_180,
    checkouts_hit: totals.checkouts_hit,
    best_checkout: totals.best_checkout,
    matches_played: matches.matches_played,
    matches_won: matches.matches_won,
    matches_lost: Math.max(0, matches.matches_played - matches.matches_won),
    legs_won: matches.legs_won,
    average_history: recentAverages,
  };
}

module.exports = { register, computePlayerStats };
