'use strict';

const db = require('../db/database');
const { ok, created, badRequest, notFound } = require('../lib/http-utils');
const { suggestCheckout } = require('../lib/checkout');

const STARTING_SCORE = { '501': 501, '301': 301 };

function register(router) {
  router.get('/api/matches', (req, res) => {
    const matches = db.all(`
      SELECT m.*,
        (SELECT json_group_array(json_object('id', p.id, 'name', p.name, 'color', p.color, 'order', mp.player_order))
         FROM match_players mp JOIN players p ON p.id = mp.player_id
         WHERE mp.match_id = m.id) AS players_json
      FROM matches m
      ORDER BY m.created_at DESC
    `).map(rowToMatchSummary);
    ok(res, matches);
  });

  router.post('/api/matches', (req, res) => {
    const { game_type, legs_to_win, player_ids, tournament_id, round } = req.body;

    if (!STARTING_SCORE[game_type]) return badRequest(res, 'game_type doit être "501" ou "301".');
    if (!Array.isArray(player_ids) || player_ids.length < 2) {
      return badRequest(res, 'Il faut au moins 2 joueurs.');
    }
    const legsToWin = Number.isInteger(legs_to_win) && legs_to_win > 0 ? legs_to_win : 3;

    for (const pid of player_ids) {
      if (!db.get('SELECT id FROM players WHERE id = ?', [pid])) {
        return badRequest(res, `Joueur introuvable: ${pid}`);
      }
    }

    const match = db.transaction(() => {
      const { lastInsertRowid: matchId } = db.run(
        'INSERT INTO matches (game_type, legs_to_win, status, tournament_id, round) VALUES (?, ?, ?, ?, ?)',
        [game_type, legsToWin, 'in_progress', tournament_id || null, round || null]
      );
      player_ids.forEach((pid, idx) => {
        db.run('INSERT INTO match_players (match_id, player_id, player_order) VALUES (?, ?, ?)', [matchId, pid, idx]);
      });
      db.run(
        'INSERT INTO legs (match_id, leg_number, starting_player_id, status) VALUES (?, 1, ?, ?)',
        [matchId, player_ids[0], 'in_progress']
      );
      return db.get('SELECT * FROM matches WHERE id = ?', [matchId]);
    });

    created(res, getMatchDetail(match.id));
  });

  router.get('/api/matches/:id', (req, res) => {
    const detail = getMatchDetail(req.params.id);
    if (!detail) return notFound(res, 'Partie introuvable.');
    ok(res, detail);
  });

  router.delete('/api/matches/:id', (req, res) => {
    const match = db.get('SELECT * FROM matches WHERE id = ?', [req.params.id]);
    if (!match) return notFound(res, 'Partie introuvable.');
    db.run('DELETE FROM matches WHERE id = ?', [req.params.id]);
    ok(res, { deleted: true });
  });

  // Enregistre un tour (visite de fléchettes) pour le joueur dont c'est le tour.
  router.post('/api/matches/:id/turns', (req, res) => {
    const match = db.get('SELECT * FROM matches WHERE id = ?', [req.params.id]);
    if (!match) return notFound(res, 'Partie introuvable.');
    if (match.status !== 'in_progress') return badRequest(res, 'Cette partie est déjà terminée.');

    const { player_id, score, darts_used, checkout_darts } = req.body;
    if (!Number.isInteger(score) || score < 0 || score > 180) {
      return badRequest(res, 'Le score doit être un entier entre 0 et 180.');
    }

    const leg = db.get('SELECT * FROM legs WHERE match_id = ? AND status = ?', [match.id, 'in_progress']);
    if (!leg) return badRequest(res, 'Aucune manche en cours pour cette partie.');

    const expected = getExpectedPlayer(match.id, leg);
    if (Number(player_id) !== expected.player_id) {
      return badRequest(res, `Ce n'est pas le tour de ce joueur (attendu: joueur ${expected.player_id}).`);
    }

    const remainingBefore = getRemaining(leg.id, player_id, match.game_type);
    let remainingAfter = remainingBefore - score;
    let isBust = false;
    let isCheckout = false;
    let effectiveDarts = Number.isInteger(darts_used) && darts_used >= 1 && darts_used <= 3 ? darts_used : 3;

    if (remainingAfter < 0 || remainingAfter === 1) {
      isBust = true;
      remainingAfter = remainingBefore;
      effectiveDarts = 3;
    } else if (remainingAfter === 0) {
      isCheckout = true;
      effectiveDarts = Number.isInteger(checkout_darts) && checkout_darts >= 1 && checkout_darts <= 3 ? checkout_darts : 3;
    }

    const turnNumber = db.get('SELECT COUNT(*) AS c FROM turns WHERE leg_id = ?', [leg.id]).c + 1;

    const result = db.transaction(() => {
      db.run(
        `INSERT INTO turns (leg_id, match_id, player_id, turn_number, score, darts_used, is_bust, is_checkout, remaining_before, remaining_after)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [leg.id, match.id, player_id, turnNumber, isBust ? score : score, effectiveDarts, isBust ? 1 : 0, isCheckout ? 1 : 0, remainingBefore, remainingAfter]
      );

      let legFinished = false;
      let matchFinished = false;

      if (isCheckout) {
        legFinished = true;
        db.run('UPDATE legs SET status = ?, winner_player_id = ?, finished_at = datetime(\'now\') WHERE id = ?', [
          'finished', player_id, leg.id,
        ]);

        const legsWon = db.get('SELECT COUNT(*) AS c FROM legs WHERE match_id = ? AND winner_player_id = ?', [match.id, player_id]).c;

        if (legsWon >= match.legs_to_win) {
          matchFinished = true;
          db.run('UPDATE matches SET status = ?, winner_player_id = ?, finished_at = datetime(\'now\') WHERE id = ?', [
            'finished', player_id, match.id,
          ]);
        } else {
          const players = db.all('SELECT player_id FROM match_players WHERE match_id = ? ORDER BY player_order ASC', [match.id]);
          const nextLegNumber = leg.leg_number + 1;
          const starter = players[(nextLegNumber - 1) % players.length].player_id;
          db.run('INSERT INTO legs (match_id, leg_number, starting_player_id, status) VALUES (?, ?, ?, ?)', [
            match.id, nextLegNumber, starter, 'in_progress',
          ]);
        }
      }

      return { legFinished, matchFinished };
    });

    ok(res, { ...getMatchDetail(match.id), event: result });
  });

  // Annule le dernier tour enregistré (utile en cas d'erreur de saisie).
  router.post('/api/matches/:id/undo', (req, res) => {
    const match = db.get('SELECT * FROM matches WHERE id = ?', [req.params.id]);
    if (!match) return notFound(res, 'Partie introuvable.');

    const lastTurn = db.get('SELECT * FROM turns WHERE match_id = ? ORDER BY id DESC LIMIT 1', [match.id]);
    if (!lastTurn) return badRequest(res, 'Aucun tour à annuler.');

    db.transaction(() => {
      const leg = db.get('SELECT * FROM legs WHERE id = ?', [lastTurn.leg_id]);

      if (lastTurn.is_checkout) {
        // Ce tour avait terminé la manche (et peut-être la partie) : on annule tout ça.
        const nextLeg = db.get('SELECT * FROM legs WHERE match_id = ? AND leg_number = ?', [match.id, leg.leg_number + 1]);
        if (nextLeg) {
          const nextLegTurns = db.get('SELECT COUNT(*) AS c FROM turns WHERE leg_id = ?', [nextLeg.id]).c;
          if (nextLegTurns === 0) db.run('DELETE FROM legs WHERE id = ?', [nextLeg.id]);
        }
        db.run('UPDATE legs SET status = ?, winner_player_id = NULL, finished_at = NULL WHERE id = ?', ['in_progress', leg.id]);
        if (match.status === 'finished') {
          db.run('UPDATE matches SET status = ?, winner_player_id = NULL, finished_at = NULL WHERE id = ?', ['in_progress', match.id]);
        }
      }
      db.run('DELETE FROM turns WHERE id = ?', [lastTurn.id]);
    });

    ok(res, getMatchDetail(match.id));
  });

  router.get('/api/checkout-suggestion', (req, res) => {
    const url = new URL(req.url, 'http://localhost');
    const remaining = Number(url.searchParams.get('remaining'));
    const dartsLeft = Number(url.searchParams.get('dartsLeft')) || 3;
    if (!Number.isInteger(remaining)) return badRequest(res, 'Paramètre "remaining" requis.');
    ok(res, suggestCheckout(remaining, dartsLeft));
  });
}

function rowToMatchSummary(row) {
  return { ...row, players: JSON.parse(row.players_json || '[]'), players_json: undefined };
}

function getExpectedPlayer(matchId, leg) {
  const players = db.all('SELECT player_id FROM match_players WHERE match_id = ? ORDER BY player_order ASC', [matchId]);
  const turnsPlayed = db.get('SELECT COUNT(*) AS c FROM turns WHERE leg_id = ?', [leg.id]).c;
  const starterIdx = players.findIndex((p) => p.player_id === leg.starting_player_id);
  const idx = (starterIdx + turnsPlayed) % players.length;
  return { player_id: players[idx].player_id, index: idx };
}

function getRemaining(legId, playerId, gameType) {
  const start = STARTING_SCORE[gameType];
  const scored = db.get('SELECT COALESCE(SUM(score), 0) AS s FROM turns WHERE leg_id = ? AND player_id = ? AND is_bust = 0', [legId, playerId]).s;
  return start - scored;
}

function getMatchDetail(matchId) {
  const match = db.get('SELECT * FROM matches WHERE id = ?', [matchId]);
  if (!match) return null;

  const players = db.all(`
    SELECT p.id, p.name, p.color, mp.player_order
    FROM match_players mp JOIN players p ON p.id = mp.player_id
    WHERE mp.match_id = ? ORDER BY mp.player_order ASC
  `, [matchId]);

  const legs = db.all('SELECT * FROM legs WHERE match_id = ? ORDER BY leg_number ASC', [matchId]);

  const legsDetailed = legs.map((leg) => {
    const turns = db.all('SELECT * FROM turns WHERE leg_id = ? ORDER BY turn_number ASC, id ASC', [leg.id]);
    const remaining = {};
    players.forEach((p) => { remaining[p.id] = getRemaining(leg.id, p.id, match.game_type); });
    return { ...leg, turns, remaining };
  });

  const legsWon = {};
  players.forEach((p) => {
    legsWon[p.id] = db.get('SELECT COUNT(*) AS c FROM legs WHERE match_id = ? AND winner_player_id = ?', [matchId, p.id]).c;
  });

  const currentLeg = legsDetailed.find((l) => l.status === 'in_progress') || null;
  let nextToThrow = null;
  if (currentLeg) {
    nextToThrow = getExpectedPlayer(matchId, currentLeg).player_id;
  }

  return {
    ...match,
    players,
    legs: legsDetailed,
    legs_won: legsWon,
    current_leg: currentLeg,
    next_to_throw: nextToThrow,
    starting_score: STARTING_SCORE[match.game_type],
  };
}

module.exports = { register, getMatchDetail };
