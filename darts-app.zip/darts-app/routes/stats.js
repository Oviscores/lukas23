'use strict';

const db = require('../db/database');
const { ok } = require('../lib/http-utils');
const { computePlayerStats } = require('./players');

function register(router) {
  router.get('/api/stats/leaderboard', (req, res) => {
    const players = db.all('SELECT id, name, color FROM players');
    const leaderboard = players
      .map((p) => ({ ...p, stats: computePlayerStats(p.id) }))
      .filter((p) => p.stats.matches_played > 0)
      .sort((a, b) => b.stats.average - a.stats.average);
    ok(res, leaderboard);
  });

  router.get('/api/stats/overview', (req, res) => {
    const totals = db.get(`
      SELECT
        (SELECT COUNT(*) FROM players) AS total_players,
        (SELECT COUNT(*) FROM matches) AS total_matches,
        (SELECT COUNT(*) FROM matches WHERE status = 'in_progress') AS matches_in_progress,
        (SELECT COUNT(*) FROM legs WHERE status = 'finished') AS total_legs,
        (SELECT COUNT(*) FROM turns WHERE score = 180 AND is_bust = 0) AS total_180s,
        (SELECT COUNT(*) FROM tournaments) AS total_tournaments
    `);
    ok(res, totals);
  });
}

module.exports = { register };
