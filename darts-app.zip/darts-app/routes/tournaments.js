'use strict';

const db = require('../db/database');
const { ok, created, badRequest, notFound } = require('../lib/http-utils');

function register(router) {
  router.get('/api/tournaments', (req, res) => {
    const tournaments = db.all('SELECT * FROM tournaments ORDER BY created_at DESC');
    ok(res, tournaments);
  });

  router.post('/api/tournaments', (req, res) => {
    const { name, format, game_type, legs_to_win, player_ids } = req.body;
    if (!name || !name.trim()) return badRequest(res, 'Le nom du tournoi est requis.');
    if (!['round_robin', 'knockout'].includes(format)) return badRequest(res, 'format doit être "round_robin" ou "knockout".');
    if (!['501', '301'].includes(game_type)) return badRequest(res, 'game_type doit être "501" ou "301".');
    if (!Array.isArray(player_ids) || player_ids.length < 2) return badRequest(res, 'Il faut au moins 2 joueurs.');

    const legsToWin = Number.isInteger(legs_to_win) && legs_to_win > 0 ? legs_to_win : 3;

    const tournament = db.transaction(() => {
      const { lastInsertRowid: tournamentId } = db.run(
        'INSERT INTO tournaments (name, format, game_type, legs_to_win, status) VALUES (?, ?, ?, ?, ?)',
        [name.trim(), format, game_type, legsToWin, 'in_progress']
      );
      player_ids.forEach((pid) => {
        db.run('INSERT INTO tournament_players (tournament_id, player_id) VALUES (?, ?)', [tournamentId, pid]);
      });

      if (format === 'round_robin') {
        generateRoundRobin(tournamentId, player_ids, game_type, legsToWin);
      } else {
        generateKnockoutRound(tournamentId, player_ids, game_type, legsToWin, 1);
      }

      return db.get('SELECT * FROM tournaments WHERE id = ?', [tournamentId]);
    });

    created(res, getTournamentDetail(tournament.id));
  });

  router.get('/api/tournaments/:id', (req, res) => {
    const detail = getTournamentDetail(req.params.id);
    if (!detail) return notFound(res, 'Tournoi introuvable.');
    ok(res, detail);
  });

  router.delete('/api/tournaments/:id', (req, res) => {
    const t = db.get('SELECT * FROM tournaments WHERE id = ?', [req.params.id]);
    if (!t) return notFound(res, 'Tournoi introuvable.');
    db.run('DELETE FROM tournaments WHERE id = ?', [req.params.id]);
    ok(res, { deleted: true });
  });

  // Pour un tournoi à élimination directe : génère le tour suivant une fois
  // tous les matchs du tour courant terminés.
  router.post('/api/tournaments/:id/advance', (req, res) => {
    const t = db.get('SELECT * FROM tournaments WHERE id = ?', [req.params.id]);
    if (!t) return notFound(res, 'Tournoi introuvable.');
    if (t.format !== 'knockout') return badRequest(res, 'Seuls les tournois à élimination directe se font avancer round par round.');

    const currentRound = db.get('SELECT MAX(round) AS r FROM matches WHERE tournament_id = ?', [t.id]).r || 1;
    const roundMatches = db.all('SELECT * FROM matches WHERE tournament_id = ? AND round = ?', [t.id, currentRound]);
    const unfinished = roundMatches.filter((m) => m.status !== 'finished');
    if (unfinished.length > 0) return badRequest(res, `${unfinished.length} match(s) du tour ${currentRound} ne sont pas encore terminés.`);

    const winners = roundMatches.map((m) => m.winner_player_id);

    if (winners.length === 1) {
      db.run('UPDATE tournaments SET status = ?, finished_at = datetime(\'now\') WHERE id = ?', ['finished', t.id]);
      return ok(res, getTournamentDetail(t.id));
    }

    db.transaction(() => {
      generateKnockoutRound(t.id, winners, t.game_type, t.legs_to_win, currentRound + 1);
    });
    ok(res, getTournamentDetail(t.id));
  });
}

function generateRoundRobin(tournamentId, playerIds, gameType, legsToWin) {
  for (let i = 0; i < playerIds.length; i++) {
    for (let j = i + 1; j < playerIds.length; j++) {
      createTournamentMatch(tournamentId, [playerIds[i], playerIds[j]], gameType, legsToWin, 1);
    }
  }
}

function generateKnockoutRound(tournamentId, playerIds, gameType, legsToWin, round) {
  const shuffled = [...playerIds];
  const pairs = [];
  while (shuffled.length > 0) {
    const a = shuffled.shift();
    const b = shuffled.shift();
    pairs.push([a, b]);
  }
  for (const pair of pairs) {
    if (pair[1] === undefined) {
      // Nombre impair de joueurs : ce joueur passe directement au tour suivant (bye).
      // On matérialise cela par un match déjà terminé avec un seul joueur inscrit.
      const { lastInsertRowid: matchId } = db.run(
        'INSERT INTO matches (game_type, legs_to_win, status, winner_player_id, tournament_id, round, finished_at) VALUES (?, ?, ?, ?, ?, ?, datetime(\'now\'))',
        [gameType, legsToWin, 'finished', pair[0], tournamentId, round]
      );
      db.run('INSERT INTO match_players (match_id, player_id, player_order) VALUES (?, ?, 0)', [matchId, pair[0]]);
    } else {
      createTournamentMatch(tournamentId, pair, gameType, legsToWin, round);
    }
  }
}

function createTournamentMatch(tournamentId, playerIds, gameType, legsToWin, round) {
  const { lastInsertRowid: matchId } = db.run(
    'INSERT INTO matches (game_type, legs_to_win, status, tournament_id, round) VALUES (?, ?, ?, ?, ?)',
    [gameType, legsToWin, 'in_progress', tournamentId, round]
  );
  playerIds.forEach((pid, idx) => {
    db.run('INSERT INTO match_players (match_id, player_id, player_order) VALUES (?, ?, ?)', [matchId, pid, idx]);
  });
  db.run('INSERT INTO legs (match_id, leg_number, starting_player_id, status) VALUES (?, 1, ?, ?)', [
    matchId, playerIds[0], 'in_progress',
  ]);
}

function getTournamentDetail(tournamentId) {
  const tournament = db.get('SELECT * FROM tournaments WHERE id = ?', [tournamentId]);
  if (!tournament) return null;

  const players = db.all(`
    SELECT p.* FROM tournament_players tp JOIN players p ON p.id = tp.player_id
    WHERE tp.tournament_id = ? ORDER BY p.name COLLATE NOCASE ASC
  `, [tournamentId]);

  const matches = db.all(`
    SELECT m.*,
      (SELECT json_group_array(json_object('id', p.id, 'name', p.name, 'color', p.color))
       FROM match_players mp JOIN players p ON p.id = mp.player_id WHERE mp.match_id = m.id) AS players_json
    FROM matches m WHERE m.tournament_id = ? ORDER BY m.round ASC, m.id ASC
  `, [tournamentId]).map((m) => ({ ...m, players: JSON.parse(m.players_json || '[]'), players_json: undefined }));

  let standings = null;
  if (tournament.format === 'round_robin') {
    standings = players.map((p) => {
      const played = matches.filter((m) => m.status === 'finished' && m.players.some((pl) => pl.id === p.id));
      const wins = played.filter((m) => m.winner_player_id === p.id).length;
      const legsFor = db.get(`
        SELECT COUNT(*) AS c FROM legs l JOIN matches m ON m.id = l.match_id
        WHERE m.tournament_id = ? AND l.winner_player_id = ?
      `, [tournamentId, p.id]).c;
      const legsAgainst = db.get(`
        SELECT COUNT(*) AS c FROM legs l JOIN matches m ON m.id = l.match_id
        WHERE m.tournament_id = ? AND l.status = 'finished' AND l.winner_player_id != ?
          AND m.id IN (SELECT match_id FROM match_players WHERE player_id = ?)
      `, [tournamentId, p.id, p.id]).c;
      return {
        player_id: p.id, name: p.name, color: p.color,
        matches_played: played.length, wins, losses: played.length - wins,
        legs_for: legsFor, legs_against: legsAgainst,
      };
    }).sort((a, b) => b.wins - a.wins || (b.legs_for - b.legs_against) - (a.legs_for - a.legs_against));
  }

  const currentRound = matches.length ? Math.max(...matches.map((m) => m.round || 1)) : null;
  const roundComplete = currentRound
    ? matches.filter((m) => m.round === currentRound).every((m) => m.status === 'finished')
    : false;

  return { ...tournament, players, matches, standings, current_round: currentRound, round_complete: roundComplete };
}

module.exports = { register };
