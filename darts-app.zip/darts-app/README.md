# 🎯 Fléchettes — App de suivi de parties

Application web complète pour gérer des parties de fléchettes (501 / 301) : joueurs, scores en direct,
statistiques et tournois. **Zéro dépendance externe** : uniquement Node.js (module natif `node:sqlite`
pour la base de données + `http` pour le serveur), donc aucune installation `npm install` n'est nécessaire.

## Prérequis

- Node.js **22.5 ou supérieur** (le module `node:sqlite` est requis). Vérifiez avec `node -v`.
  Si besoin, installez la dernière version LTS depuis https://nodejs.org.

## Démarrage

```bash
cd darts-app
node server.js
```

Puis ouvrez votre navigateur sur **http://localhost:3000**.

Pour changer le port : `PORT=4000 node server.js`.

La base de données SQLite est créée automatiquement au premier lancement dans `db/darts.sqlite3`
(rien à configurer). Elle persiste entre les redémarrages — pour repartir de zéro, supprimez ce fichier.

## Fonctionnalités

- **Joueurs** : création de profils avec couleur, historique et statistiques individuelles.
- **Parties 501 / 301** : saisie du score en direct via un clavier numérique ou des scores rapides
  (26, 41, 60, 100, 140, 180…), détection automatique des *bust*, suggestion de finition (checkout),
  et bouton d'annulation du dernier tour en cas d'erreur de saisie.
- **Historique** : liste de toutes les parties jouées, en cours ou terminées.
- **Statistiques** : moyenne aux 3 fléchettes, meilleur tour, nombre de 180, meilleur checkout,
  classement général de tous les joueurs, évolution de la moyenne dans le temps.
- **Tournois** : format poule (tous contre tous, avec classement victoires/défaites et manches)
  ou élimination directe (bracket avec gestion des "byes" et progression tour par tour).

## Structure du projet

```
darts-app/
├── server.js              # Serveur HTTP (routage + fichiers statiques)
├── db/
│   ├── schema.sql          # Schéma complet de la base de données
│   └── database.js         # Connexion SQLite + helpers de requêtes
├── lib/
│   ├── router.js           # Petit routeur maison (sans dépendance)
│   ├── http-utils.js        # Helpers de réponse JSON
│   └── checkout.js          # Algorithme de suggestion de finition
├── routes/
│   ├── players.js          # API joueurs + calcul des statistiques
│   ├── matches.js          # API parties : création, tours, undo, moteur de jeu
│   ├── stats.js             # API classement général
│   └── tournaments.js       # API tournois (poule / élimination directe)
└── public/                 # Frontend (HTML/CSS/JS vanilla, sans framework)
```

## Modèle de données

Le cœur de l'application est une base **SQLite relationnelle complète** :

- `players` — les joueurs
- `tournaments` / `tournament_players` — tournois et leurs participants
- `matches` / `match_players` — une partie (best of N manches) et ses joueurs
- `legs` — chaque manche d'une partie
- `turns` — chaque tour de 3 fléchettes joué (score, bust, checkout, reste)

Toutes les statistiques (moyennes, 180, checkouts…) sont calculées à la volée par des requêtes SQL
agrégées sur ces tables — rien n'est dupliqué ou stocké en double.

## Notes techniques

- Le module `node:sqlite` est encore marqué "expérimental" par Node.js (avertissement inoffensif
  affiché au démarrage) mais est stable pour cet usage.
- L'application n'a aucune dépendance npm : elle démarre instantanément, sans risque de blocage
  réseau ou de package manquant.
